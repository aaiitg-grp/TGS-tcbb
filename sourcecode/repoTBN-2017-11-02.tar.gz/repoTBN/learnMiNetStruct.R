computEntropy <- function(input.data)
{
  n <- ncol(input.data)
  entropy.matrix <- matrix(0, nrow = 1, ncol = n)

  for(i in 1:n)
  {
     c1 <-  var(input.data[,i])
     entropy.matrix[i] <- .5*log((2*pi*exp(1))*c1)
  }
  return(entropy.matrix) 
}

############################################################################################

learnMiNetStructZstat <- function(mut.info.matrix, mi.net.adj.matrix, entropy.matrix, alpha)
{
  n <- ncol(mut.info.matrix)
  
  threshold <- qnorm(1-(alpha/2))
  
  for(i in 1:(n-1))
  {
    for(j in (i+1):n)
    { 
      value <- mut.info.matrix[i,j]/(entropy.matrix[i]+entropy.matrix[j])
       fisher_transform <- .5*log((1+value)/(1-value))
        value1 <- sqrt(n - 3) * abs(fisher_transform)
        
        if(value1 > threshold)
        {
          mi.net.adj.matrix[i,j] <- 1
          mi.net.adj.matrix[j,i] <- 1
        }
    }
  }
  return(mi.net.adj.matrix)
}

############################################################################################

learnMiNetStructRowMedian <- function(mut.info.matrix, mi.net.adj.matrix, num.nodes)
{
  for (rowIdx in 1:num.nodes)
  {
    threshold <- median(mut.info.matrix[rowIdx, -rowIdx])

    for (colIdx in 1:num.nodes)
    {
      if ((colIdx != rowIdx) & (mut.info.matrix[rowIdx, colIdx] >= threshold))
      {
        mi.net.adj.matrix[rowIdx, colIdx] <- 1          
      }
    }
  }
  
  return(mi.net.adj.matrix)
}

############################################################################################
## Goal: Learn CLR net. Replace all non-zero edge weights with 1.

library(minet)

learnMiNetStructClr <- function(mut.info.matrix, mi.net.adj.matrix, num.nodes)
{
  mi.net.adj.matrix.wt <- minet::clr(mut.info.matrix) # weighted adj matrix
  
  # Replace 'NaN' with zero. 'NaN' is produced when a corr. variable has variance zero.
  mi.net.adj.matrix.wt[is.nan(mi.net.adj.matrix.wt)] <- 0
  
  writeLines('\n mi.net.adj.matrix.wt = \n')
  print(mi.net.adj.matrix.wt)
  save(mi.net.adj.matrix.wt, file = paste(getwd(), 'asset/mi.net.adj.matrix.wt.RData', sep = '/'))
  
  for (rowIdx in 1:num.nodes)
  {
    for (colIdx in 1:num.nodes)
    {
      if (mi.net.adj.matrix.wt[rowIdx, colIdx] != 0)
      {
        mi.net.adj.matrix[rowIdx, colIdx] <- 1
      }
    }
  }
  
  return(mi.net.adj.matrix)
}

############################################################################################
## Goal: Learn CLR net. For each node, retain top 'max.fanin' number of neighbours w.r.t. edge weight
## and remove rest of the edges. Tie is broken in favour of the neighbour having smaller node index.
## If there are less than that number of edges for a node, then retain all its neighbours.

library(minet)

learnMiNetStructClrMfi <- function(mut.info.matrix, mi.net.adj.matrix, num.nodes, max.fanin)
{
  mi.net.adj.matrix.wt <- minet::clr(mut.info.matrix) # weighted adj matrix
  
  # Replace 'NaN' with zero. 'NaN' is produced when a corr. variable has variance zero.
  mi.net.adj.matrix.wt[is.nan(mi.net.adj.matrix.wt)] <- 0
  
  writeLines('\n mi.net.adj.matrix.wt = \n')
  print(mi.net.adj.matrix.wt)
  save(mi.net.adj.matrix.wt, file = paste(getwd(), 'asset/mi.net.adj.matrix.wt.RData', sep = '/'))

  # For each target node
  for (col.idx in 1:num.nodes)
  {
    # Weights of the edges with the target node
    edge.wts <- mi.net.adj.matrix.wt[, col.idx]
    
    # Count number of neighbours having positive edge weight
    num.nbrs <- length(edge.wts[edge.wts > 0])
    
    if (num.nbrs >= max.fanin)
    {
      # Return indices of the top 'max.fanin' number of neighbours w.r.t. edge weight.
      # Tie is broken in favour of the neighbour having smaller index.
      valid.nbrs <- sort(edge.wts, decreasing = TRUE, index.return = TRUE)$ix[1:max.fanin]
      
      mi.net.adj.matrix[valid.nbrs, col.idx] <- 1
      
      ## The following line is not required since 'mi.net.adj.matrix' is initialized
      ## with all zeroes
      # mi.net.adj.matrix[-(valid.nbrs), col.idx] <- 0
    }
    else if (num.nbrs < max.fanin)
    {
      # Retain all the neighbours
      mi.net.adj.matrix[edge.wts > 0, col.idx] <- 1
    }
  }
  
  return(mi.net.adj.matrix)
}

############################################################################################
