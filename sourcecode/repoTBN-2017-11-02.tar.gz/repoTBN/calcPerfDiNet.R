# Calculate performance metrics of the directed net 'inferredNet' w.r.t. the directed net 'targetNet'.
# n = Number of nodes in each of the nets.
calcPerfDiNet <-function(inferredNet, targetNet, Result, n)
{
  TrPos = 0
  TrNeg = 0
  FlPos = 0
  FlNeg = 0
  
  for(i in 1:n)
  {
    for(j in 1:n)
    {
      if(inferredNet[i,j] == 1 )
      {
        if(inferredNet[i,j] == targetNet[i,j])
        {
          #True Positive
          TrPos = TrPos + 1	 	
        }
        else
        {
          FlPos = FlPos +1
        }
      }	   
      if(inferredNet[i,j] == 0 )
      {
        if (inferredNet[i,j] == targetNet[i,j])
        {
          # True Negative
          TrNeg = TrNeg + 1
        }
        else
        {
          FlNeg = FlNeg +1
        }
        
      }
    }	
  }
  
  #------------------------------------------------------------
  # Begin: Calculate Performance Metrics
  #------------------------------------------------------------
  TPR <- TrPos/(TrPos + FlNeg)
  FPR <- FlPos/(FlPos + TrNeg)
  FDR <- FlPos/(FlPos + TrPos)
  PPV <- TrPos/(TrPos + FlPos)
  ACC <- (TrPos + TrNeg)/(TrPos + FlPos + TrNeg + FlNeg)
  F <- 2 * PPV * TPR / (PPV + TPR)
  MCC <- ((TrPos * TrNeg) - (FlNeg * FlPos)) / sqrt((TrPos + FlPos) * (TrPos + FlNeg) * (TrNeg + FlPos) * (TrNeg+FlNeg))
  
  ## Calculate AUC under ROC
  # table <- minet::validate(inferredNet, targetNet)
  # AUC <- minet::auc.roc(table)
  #------------------------------------------------------------
  # End: Calculate Performance Metrics
  #------------------------------------------------------------
  
  Result[1, 1] <- TrPos
  Result[1, 2] <- TrNeg
  Result[1, 3] <- FlPos
  Result[1, 4] <- FlNeg
  Result[1, 5] <- TPR
  Result[1, 6] <- FPR
  Result[1, 7] <- FDR
  Result[1, 8] <- PPV
  Result[1, 9] <- ACC
  Result[1, 10] <- MCC
  Result[1, 11] <- F
  # Result[1,8] <- AUC
  
  return (Result)
}