#!/usr/bin/env Rscript
## Goal of this program: Implement the TBN Algorithm.
##
## Author: Saptarshi Pyne (saptarshipyne01@gmail.com)
## Last modified on: Nov 2, 2017
##
## How to execute this script:
## Let us assume that this script is inside directory '/home/saptarshi/R/R-3.3.2/projects/repoTBN' and
## the Rscript file is inside directory '/home/saptarshi/R/R-3.3.2/bin'.
## Then, execute this script using the following commands:
## $ cd /home/saptarshi/R/R-3.3.2/projects/repoTBN/  
## $ nohup time /home/saptarshi/R/R-3.3.2/bin/Rscript TBN.R input.json &
## where 'asset/input.json' contains the user-defined parameters. A file 
## named 'nohup.out' will be generated inside 
## '/home/saptarshi/R/R-3.3.2/projects/repoTBN/'.
##
## Input: A time series gene expression dataset with multiple time series.
##
## Output: Time-varying Gene Regulatory Networks and a corresponding rolled up network.

## Remove all objects in the current workspace
rm(list = ls())

##------------------------------------------------------------
## Begin: Load the Required Libraries
##------------------------------------------------------------
## For reading from and writing to '.json' files
library(rjson)
##------------------------------------------------------------
## End: Load the Required Libraries
##------------------------------------------------------------

##------------------------------------------------------------
## Begin: Read User-defined input Params
##------------------------------------------------------------
input.args <- commandArgs(trailingOnly=TRUE)

if (length(args) != 1)
{
  stop("Exactly one input file must be supplied.", call.=FALSE)
}

input.params <- rjson::fromJSON(file = paste(getwd(), 'asset', input.args, sep = '/'))
rm(input.args)

## Input file for time-series gene expression data
input.data.filename <- input.params$input.data.filename
input.data.filename <- paste(getwd(), 'asset', input.data.filename, sep = '/')

## Number of time points (T)
num.timepts <- input.params$num.timepts

## True rolled network file.
## If 'true.net.filename' is an empty string, then the true rolled network
## is not known a prior. Otherwise, it is known a prior and would be used
## to evaluate performance metrics of the predicted rolled network.
true.net.filename <- input.params$true.net.filename
if (true.net.filename != '')
{
  true.net.filename <- paste(getwd(), 'asset', true.net.filename, sep = '/')
}

## Input file for Wild Type (WT) values of the genes.
## If 'input.wt.data.filename' is an empty string, then
## the WT values are not required for further computation. Otherwise, 
## WT values are required for further computation.
input.wt.data.filename <- input.params$input.wt.data.filename
if (input.wt.data.filename != '')
{
  input.wt.data.filename <- paste(getwd(), 'asset', input.wt.data.filename, sep = '/')
}

## is.discrete is true or false, implying whether the input data file is already
## discretized or not.
is.discrete <- input.params$is.discrete

## Number of discrete levels in the input data or
## number of discrete levels in which the data needs to be discretized.
num.discr.levels <- input.params$num.discr.levels

## Name of the discretization algorithm to be applied
discr.algo <- input.params$discr.algo

## The maximum number of regulators a gene can have
max.fanin <- input.params$max.fanin

## allow.self.loop takes values true or false, dependending on whether 
## to allow self loops in the predicted rolled network or not.
allow.self.loop <- input.params$allow.self.loop

rm(input.params)
##------------------------------------------------------------
## End: Read User-defined input Params
##------------------------------------------------------------

##------------------------------------------------------------
## Begin: Create the output directory
##------------------------------------------------------------
init.path <- getwd()

## Output directory name
output.dirname <- paste('asset/output', format(Sys.time(), "%Y%m%d%H%M%S"), sep = '')
output.dirname <- paste(init.path, output.dirname, sep = '/')

if(.Platform$OS.type == "unix") {
  if(! output.dirname %in% system("ls" ,intern=TRUE))
  {
    system(paste('mkdir ', output.dirname, sep = ''))
  }
} else{# if(.Platform$OS.type == "unix"){
  shell(paste('mkdir ', output.dirname, sep = ''), intern = TRUE, mustWork =NA)
}
##------------------------------------------------------------
## End: Create the output directory
##------------------------------------------------------------

##------------------------------------------------------------
## Begin: Load the Required External Functions
##------------------------------------------------------------
source(paste(init.path, 'discretizeData.R', sep = '/'))

# Parallel programming with degree of parallelism 1 and Serial Programming
source(paste(init.path, 'learnDbnStruct3dParDeg1.R', sep = '/'))

source(paste(init.path, 'calcPerfDiNet.R', sep = '/'))
source(paste(init.path, 'CompareNet.R', sep = '/'))
source(paste(init.path, 'rollDbn.R', sep = '/'))
##------------------------------------------------------------
## End: Load the Required External Functions
##------------------------------------------------------------

##------------------------------------------------------------
## Begin: Main Program
##------------------------------------------------------------

## Print the output dir name in 'nohup.out'
print('The output directory name is:')
print(output.dirname)
print('') ## to append a blank line

## Save console output in a file named 'output.txt' inside the output directory.
output.filename <- paste(output.dirname, 'output.txt', sep = '/')
output.file.conn <- file(output.filename, open = "wt")
sink(output.file.conn)

##------------------------------------------------------------
## Begin: Read input data file
##------------------------------------------------------------

## Begin: Find file extension of the input data file. Only '.tsv' and '.RData'
## are allowed.
## Split the string at every '.' and consider the last substring as the 
## file extension.
input.data.filename.ext <- unlist(strsplit(input.data.filename, '[.]'))
## End: Find file extension of the input data file. Only '.tsv' and '.RData'
## are allowed.

if (input.data.filename.ext[length(input.data.filename.ext)] == 'tsv')
{
  input.data <- read.table(input.data.filename, header = TRUE, sep="\t")
  
  timepts.names <- input.data[1:num.timepts, 1]
  
  ## Remove first col i.e. the time point names
  input.data <- input.data[, -1]
  
} else if (input.data.filename.ext[length(input.data.filename.ext)] == 'RData')
{
  ## Loads an object named input.data
  load(input.data.filename)
  
  timepts.names <- 1:num.timepts
}

num.nodes <- ncol(input.data)
node.names <- colnames(input.data)

## Max fanin must be restricted to 14. Because, it is empirically observed that bnstruct::learn.network()
## function can learn a BN with upto 15 nodes without segmentation fault, given a 32 GB main memory. A max 
## fanin restriction of 14 limits the number of nodes in the to-be-learnt BN to 15 (1 target node and a 
## maximum of 14 candidate parents).
max.fanin <- min(num.nodes, 14)

num.samples.per.timept <- (nrow(input.data) / num.timepts)

## source(paste(init.path, 'discretizeData.R', sep = '/'))
## If input data is already discretized
if (is.discrete)
{
  input.data.discr <- input.data
  
} else
{
  if (discr.algo == '')
  {
    stop('Please specify the value of discr.algo.')
    
  } else if (discr.algo == 'discretizeData.2L.wt.l')
  {
    input.data.discr <- discretizeData.2L.wt.l(input.data, input.wt.data.filename)
    
  } else if (discr.algo == 'discretizeData.2L.Tesla')
  {
    input.data.discr <- discretizeData.2L.Tesla(input.data)
  }
  
  save(input.data.discr, file = paste(output.dirname, 'input.data.discr.RData', sep = '/'))
}
##------------------------------------------------------------
## End: Read input data
##------------------------------------------------------------

##------------------------------------------------------------
## Begin: Learn Network Structures
##------------------------------------------------------------

start.time <- proc.time() # start the timer

input.data.discr.matrix <- data.matrix(input.data.discr)

input.data.discr.3D <- array(NA, c(num.timepts, num.nodes, num.samples.per.timept),
                         dimnames = c(list(timepts.names), list(node.names),
                                      list(1:num.samples.per.timept)))

for (sampleIdx in 1:num.samples.per.timept)
{
  start.rowIdx <- (1 + (num.timepts * (sampleIdx - 1)))
  end.rowIIdx <- (num.timepts * sampleIdx)
  input.data.discr.3D[ , , sampleIdx] <- input.data.discr.matrix[start.rowIdx:end.rowIIdx, ]
}

unrolled.DBN.adj.matrix <- learnDbnStructMo1Layer3dParDeg1(input.data.discr.3D, node.names, num.discr.levels, 
                                                           nodes.discr.sizes, num.nodes, num.timepts, max.fanin)

save(unrolled.DBN.adj.matrix, file = paste(output.dirname, 'unrolled.DBN.adj.matrix.RData', sep = '/'))
rm(input.data.discr, input.data.discr.matrix, input.data.discr.3D)

## Learn the rolled DBN adj matrix
## source(paste(init.path, 'rollDbn.R', sep = '/'))
# rolled.DBN.adj.matrix <- rollDbn(num.nodes, node.names, num.timepts, unrolled.DBN.adj.matrix, roll.method, allow.self.loop)
rolled.DBN.adj.matrix <- rollDbn(num.nodes, node.names, num.timepts, unrolled.DBN.adj.matrix, 'any', FALSE)
di.net.adj.matrix <- rolled.DBN.adj.matrix
rm(rolled.DBN.adj.matrix, rolled.DBN.adj.matrix)

save(di.net.adj.matrix, file = paste(output.dirname, 'di.net.adj.matrix.RData', sep = '/'))
##------------------------------------------------------------
## End: Learn Network Structures
##------------------------------------------------------------

## If the true rolled network is known a prior, then evaluate the performance
## metrics of the predicted rolled network.
if (true.net.filename != '')
{
  predicted.net.adj.matrix <- di.net.adj.matrix
  
  ## Loads R obj 'true.net.adj.matrix'
  load(true.net.filename)
  
  ## Begin: Create the format for result
  Result <- matrix(0, nrow = 1, ncol = 11)
  colnames(Result) <- list('TP', 'TN', 'FP', 'FN', 'TPR', 'FPR', 'FDR', 'PPV', 'ACC', 'MCC',  'F')
  # ## End: Create the format for result
  
  ResultVsTrue <- calcPerfDiNet(predicted.net.adj.matrix, true.net.adj.matrix, Result, num.nodes)
  rm(Result)
  writeLines('Result TBN vs True = \n')
  print(ResultVsTrue)
  rm(ResultVsTrue)
}

rm(di.net.adj.matrix)

elapsed.time <- (proc.time() - start.time) # Stop the timer
writeLines('elapsed.time = \n')
print(elapsed.time)

sink()

##------------------------------------------------------------
## Begin: Save R session info in a File
##------------------------------------------------------------
sink(paste(output.dirname, 'sessionInfo.txt', sep = '/'))
sessionInfo()
sink()
##------------------------------------------------------------
## End: Save R session info in a File
##------------------------------------------------------------

##------------------------------------------------------------
## End: Main program
##------------------------------------------------------------

##------------------------------------------------------------
## Begin: References
##------------------------------------------------------------
## 
##------------------------------------------------------------
## End: References
##------------------------------------------------------------
