# Returns 1 if 'di.net.adj.matrix' = 'cmi.net.adj.matrix' else returns 0
CompareNet <-function(di.net.adj.matrix,cmi.net.adj.matrix,num.node)
{
  for(i in 1:num.node)
  {
    for(j in 1:num.node)
    {
      if(di.net.adj.matrix[i,j] != cmi.net.adj.matrix[i,j])
      {
        return(0)
      }
    }
  }
  return (1)
}